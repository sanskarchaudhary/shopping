package com.example.gift_house1;
class Prevalent
{
    private static Users currentOnlineUser;
    static final String UserPhoneKey = "UserPhone";
    static final String UserPasswordKey = "UserPassword";
}
